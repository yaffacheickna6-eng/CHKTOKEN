import type {
  AllocationId,
  Language,
  RoadmapPhaseId,
  RoadmapStatus,
  RoadmapTaskKey,
} from "../config/site";

export type FAQAction =
  | "mining"
  | "officialTelegram"
  | "communityTelegram"
  | "explorer"
  | "buy";

type FeatureId = "mining" | "rewards" | "community";
type CommunityChannelId = "x" | "telegramOfficial" | "telegramCommunity";

export interface Translation {
  languageLabel: string;
  skipToContent: string;
  nav: {
    primary: string;
    footer: string;
    officialLinks: string;
    home: string;
    about: string;
    tokenomics: string;
    roadmap: string;
    transparency: string;
    community: string;
    faq: string;
    language: string;
    openMenu: string;
    closeMenu: string;
  };
  actions: {
    startMining: string;
    joinTelegram: string;
    buyToken: string;
    viewExplorer: string;
    copyContract: string;
    followX: string;
    joinOfficial: string;
    joinCommunity: string;
    copied: string;
    copyFailed: string;
    openLink: string;
  };
  hero: {
    eyebrow: string;
    description: string;
    networkLabel: string;
    scrollHint: string;
    imageAlt: string;
  };
  about: {
    eyebrow: string;
    title: string;
    description: string;
    features: Record<FeatureId, { title: string; description: string }>;
  };
  tokenomics: {
    eyebrow: string;
    title: string;
    description: string;
    totalSupply: string;
    allocation: string;
    total: string;
    allocationNames: Record<AllocationId, string>;
    allocationDescriptions: Record<AllocationId, string>;
    note: string;
  };
  transparency: {
    eyebrow: string;
    title: string;
    description: string;
    network: string;
    token: string;
    symbol: string;
    totalSupply: string;
    contract: string;
    unavailable: string;
  };
  howItWorks: {
    eyebrow: string;
    title: string;
    description: string;
    steps: { title: string; description: string }[];
  };
  roadmap: {
    eyebrow: string;
    title: string;
    description: string;
    statusNote: string;
    phaseLabel: string;
    statuses: Record<RoadmapStatus, string>;
    phases: Record<RoadmapPhaseId, string>;
    tasks: Record<RoadmapTaskKey, string>;
  };
  community: {
    eyebrow: string;
    title: string;
    description: string;
    channels: Record<CommunityChannelId, { title: string; description: string }>;
    socialLabels: Record<string, string>;
  };
  faq: {
    eyebrow: string;
    title: string;
    description: string;
    items: { question: string; answer: string; action?: FAQAction }[];
    actionLabels: Record<FAQAction, string>;
  };
  disclaimer: string;
  disclaimerTitle: string;
  footer: {
    tagline: string;
    navigate: string;
    social: string;
    contract: string;
    copyright: string;
  };
}

export const translations: Record<Language, Translation> = {
  en: {
    languageLabel: "English",
    skipToContent: "Skip to main content",
    nav: {
      primary: "Main navigation",
      footer: "Footer navigation",
      officialLinks: "Official social links",
      home: "Home",
      about: "About",
      tokenomics: "Tokenomics",
      roadmap: "Roadmap",
      transparency: "Transparency",
      community: "Community",
      faq: "FAQ",
      language: "Choose language",
      openMenu: "Open menu",
      closeMenu: "Close menu",
    },
    actions: {
      startMining: "Start mining",
      joinTelegram: "Join Telegram",
      buyToken: "Buy / get CHKH$",
      viewExplorer: "View on TONviewer",
      copyContract: "Copy contract",
      followX: "Follow on X",
      joinOfficial: "Join official channel",
      joinCommunity: "Join community",
      copied: "Contract copied!",
      copyFailed: "Could not copy. Please copy the address manually.",
      openLink: "Open link",
    },
    hero: {
      eyebrow: "COMMUNITY TOKEN ON TON",
      description: "A community ecosystem built around CHEIKH$, a token on the TON network.",
      networkLabel: "Built on TON",
      scrollHint: "Scroll to explore",
      imageAlt: "Black metallic token medallion with a blue crown emblem",
    },
    about: {
      eyebrow: "A COMMUNITY-LED ECOSYSTEM",
      title: "About CHEIKH$",
      description:
        "CHEIKH$ is a community token developed around a digital ecosystem combining mining, rewards, referrals, and community participation.",
      features: {
        mining: {
          title: "Mining",
          description:
            "Take part in the ecosystem and earn rewards according to the mechanisms available on the platform.",
        },
        rewards: {
          title: "Rewards",
          description:
            "A system designed to distribute rewards to the community progressively.",
        },
        community: {
          title: "Community",
          description:
            "The community is at the heart of CHEIKH$ development and evolution.",
        },
      },
    },
    tokenomics: {
      eyebrow: "CLEAR BY DESIGN",
      title: "Tokenomics",
      description: "A published supply allocation for the CHEIKH$ ecosystem.",
      totalSupply: "Total supply",
      allocation: "Allocation",
      total: "Total",
      allocationNames: {
        communityRewards: "Community & rewards",
        referralAirdrops: "Referral & airdrops",
        liquidity: "Liquidity",
        ecosystemDevelopment: "Ecosystem development",
        marketingPartnerships: "Marketing & partnerships",
        projectReserve: "Project reserve",
        teamFounder: "Team / founder",
      },
      allocationDescriptions: {
        communityRewards: "Reserved for community programs and rewards.",
        referralAirdrops: "Reserved for referral programs and airdrops.",
        liquidity: "Allocated to liquidity.",
        ecosystemDevelopment: "Reserved for ecosystem development.",
        marketingPartnerships: "Reserved for marketing and partnerships.",
        projectReserve: "Held as a project reserve.",
        teamFounder: "Allocated to the team and founder.",
      },
      note:
        "Allocations and their conditions of use may change in accordance with the project's official documentation. Any material change should be communicated publicly.",
    },
    transparency: {
      eyebrow: "VERIFY THE DETAILS",
      title: "Transparency",
      description:
        "Key token details are listed here so you can check the contract directly on the TON network.",
      network: "Network",
      token: "Token",
      symbol: "Symbol",
      totalSupply: "Total supply",
      contract: "Contract address",
      unavailable: "Data unavailable",
    },
    howItWorks: {
      eyebrow: "A SIMPLE PATH",
      title: "How CHEIKH$ Works",
      description: "Four simple steps to take part in the CHEIKH$ ecosystem.",
      steps: [
        { title: "Join", description: "Join the CHEIKH$ ecosystem." },
        {
          title: "Mine",
          description: "Take part in the mining system available through the official platform.",
        },
        {
          title: "Earn",
          description: "Accumulate rewards available under the project's rules.",
        },
        {
          title: "Grow",
          description: "Contribute to the growth of the community and ecosystem.",
        },
      ],
    },
    roadmap: {
      eyebrow: "A WORK IN PROGRESS",
      title: "Roadmap",
      description: "An outline of the project's planned areas of work.",
      statusNote:
        "Roadmap statuses are configurable and should be updated only after progress is publicly confirmed. Items describe plans, not a guarantee of delivery.",
      phaseLabel: "Phase",
      statuses: {
        completed: "Completed",
        inProgress: "In progress",
        upcoming: "Upcoming",
      },
      phases: {
        foundation: "Foundation",
        community: "Community",
        ecosystem: "Ecosystem",
        growth: "Growth",
      },
      tasks: {
        tokenCreation: "Token creation",
        brandIdentity: "CHEIKH$ identity",
        officialChannels: "Official channels",
        communityBuilding: "Community development",
        miningDevelopment: "Mining development",
        rewardsSystem: "Rewards system",
        referralSystem: "Referral system",
        platformDevelopment: "Platform development",
        liquidity: "Liquidity",
        partnerships: "Partnerships",
        newFeatures: "New features",
        ecosystemExpansion: "Ecosystem expansion",
        newIntegrations: "New integrations",
        internationalDevelopment: "International development",
        communityFeatures: "Community features",
      },
    },
    community: {
      eyebrow: "BUILT TOGETHER",
      title: "Join the CHEIKH$ Community",
      description: "Follow official updates and take part in the conversation.",
      channels: {
        x: { title: "X", description: "Follow CHEIKH$ on X." },
        telegramOfficial: {
          title: "Telegram Official",
          description: "Get official announcements and project updates.",
        },
        telegramCommunity: {
          title: "Telegram Community",
          description: "Discuss CHEIKH$, share ideas, and connect with the community.",
        },
      },
      socialLabels: {
        x: "X",
        telegramOfficial: "Telegram Official",
        telegramCommunity: "Telegram Community",
        discord: "Discord",
        youtube: "YouTube",
        tiktok: "TikTok",
        instagram: "Instagram",
        facebook: "Facebook",
        medium: "Medium",
        github: "GitHub",
        whitepaper: "Whitepaper",
      },
    },
    faq: {
      eyebrow: "GOOD TO KNOW",
      title: "Frequently asked questions",
      description: "Straightforward answers about CHEIKH$ and the CHKH$ token.",
      items: [
        {
          question: "What is CHEIKH$?",
          answer:
            "CHEIKH$ is a community-driven digital token project on TON, with an ecosystem focused on mining, rewards, referrals, and community participation.",
        },
        {
          question: "What is CHKH$?",
          answer: "CHKH$ is the symbol used to identify the CHEIKH$ token.",
        },
        {
          question: "Which blockchain does CHEIKH$ use?",
          answer: "CHEIKH$ is on the TON network.",
        },
        {
          question: "What is the total supply?",
          answer: "The stated total supply is {supply}.",
        },
        {
          question: "How can I start mining?",
          answer:
            "Use the mining bot linked below. Check the official project channels for current rules and availability.",
          action: "mining",
        },
        {
          question: "Where can I find the official Telegram?",
          answer: "The official announcement channel is linked below.",
          action: "officialTelegram",
        },
        {
          question: "Where can I find the official community?",
          answer: "The community chat is linked below.",
          action: "communityTelegram",
        },
        {
          question: "Where can I verify the token contract?",
          answer: "Open the contract on TONviewer to inspect its on-chain details.",
          action: "explorer",
        },
        {
          question: "How can I obtain CHKH$?",
          answer: "Use only a method shared through the official project channels.",
          action: "buy",
        },
        {
          question: "What are the risks?",
          answer:
            "Digital assets involve risk and may lose value. This website is not financial, investment, or legal advice. Do your own research.",
        },
      ],
      actionLabels: {
        mining: "Open the mining bot",
        officialTelegram: "Open official Telegram",
        communityTelegram: "Open community Telegram",
        explorer: "Verify on TONviewer",
        buy: "View official access link",
      },
    },
    disclaimerTitle: "Disclaimer",
    disclaimer:
      "CHEIKH$ is a community-driven digital token project. Cryptocurrency assets involve risks and their value can change. Nothing on this website constitutes financial, investment, or legal advice. Users should conduct their own research before interacting with digital assets.",
    footer: {
      tagline: "Mine. Earn. Grow.",
      navigate: "Explore",
      social: "Official links",
      contract: "CHKH$ — TON",
      copyright: "All rights reserved.",
    },
  },
  fr: {
    languageLabel: "Français",
    skipToContent: "Aller au contenu principal",
    nav: {
      primary: "Navigation principale",
      footer: "Navigation de pied de page",
      officialLinks: "Liens sociaux officiels",
      home: "Accueil",
      about: "À propos",
      tokenomics: "Tokenomics",
      roadmap: "Feuille de route",
      transparency: "Transparence",
      community: "Communauté",
      faq: "FAQ",
      language: "Choisir la langue",
      openMenu: "Ouvrir le menu",
      closeMenu: "Fermer le menu",
    },
    actions: {
      startMining: "Commencer le mining",
      joinTelegram: "Rejoindre Telegram",
      buyToken: "Acheter / obtenir CHKH$",
      viewExplorer: "Voir sur TONviewer",
      copyContract: "Copier le contrat",
      followX: "Suivre sur X",
      joinOfficial: "Rejoindre le canal officiel",
      joinCommunity: "Rejoindre la communauté",
      copied: "Contrat copié !",
      copyFailed: "Copie impossible. Veuillez copier l'adresse manuellement.",
      openLink: "Ouvrir le lien",
    },
    hero: {
      eyebrow: "TOKEN COMMUNAUTAIRE SUR TON",
      description: "Un écosystème communautaire construit autour de CHEIKH$, un token sur le réseau TON.",
      networkLabel: "Construit sur TON",
      scrollHint: "Faire défiler pour explorer",
      imageAlt: "Médaillon métallique noir orné d'une couronne bleue",
    },
    about: {
      eyebrow: "UN ÉCOSYSTÈME PORTÉ PAR LA COMMUNAUTÉ",
      title: "À propos de CHEIKH$",
      description:
        "CHEIKH$ est un token communautaire développé autour d'un écosystème numérique combinant mining, récompenses, parrainage et participation communautaire.",
      features: {
        mining: {
          title: "Mining",
          description:
            "Participez à l'écosystème et gagnez des récompenses selon les mécanismes disponibles sur la plateforme.",
        },
        rewards: {
          title: "Récompenses",
          description:
            "Un système conçu pour distribuer progressivement des récompenses à la communauté.",
        },
        community: {
          title: "Communauté",
          description:
            "La communauté est au cœur du développement et de l'évolution de CHEIKH$.",
        },
      },
    },
    tokenomics: {
      eyebrow: "LA CLARTÉ AVANT TOUT",
      title: "Tokenomics",
      description: "Une répartition publiée de l'offre de l'écosystème CHEIKH$.",
      totalSupply: "Offre totale",
      allocation: "Répartition",
      total: "Total",
      allocationNames: {
        communityRewards: "Communauté et récompenses",
        referralAirdrops: "Parrainage et airdrops",
        liquidity: "Liquidité",
        ecosystemDevelopment: "Développement de l'écosystème",
        marketingPartnerships: "Marketing et partenariats",
        projectReserve: "Réserve du projet",
        teamFounder: "Équipe / fondateur",
      },
      allocationDescriptions: {
        communityRewards: "Réservés aux programmes communautaires et aux récompenses.",
        referralAirdrops: "Réservés au parrainage et aux airdrops.",
        liquidity: "Alloués à la liquidité.",
        ecosystemDevelopment: "Réservés au développement de l'écosystème.",
        marketingPartnerships: "Réservés au marketing et aux partenariats.",
        projectReserve: "Conservés en réserve pour le projet.",
        teamFounder: "Alloués à l'équipe et au fondateur.",
      },
      note:
        "Les allocations et leurs conditions d'utilisation peuvent évoluer conformément à la documentation officielle du projet. Toute modification importante doit être communiquée publiquement.",
    },
    transparency: {
      eyebrow: "VÉRIFIER LES INFORMATIONS",
      title: "Transparence",
      description:
        "Les informations essentielles du token sont réunies ici pour vous permettre de vérifier le contrat directement sur le réseau TON.",
      network: "Réseau",
      token: "Token",
      symbol: "Symbole",
      totalSupply: "Offre totale",
      contract: "Adresse du contrat",
      unavailable: "Donnée indisponible",
    },
    howItWorks: {
      eyebrow: "UN PARCOURS SIMPLE",
      title: "Comment fonctionne CHEIKH$",
      description: "Quatre étapes simples pour participer à l'écosystème CHEIKH$.",
      steps: [
        { title: "Rejoindre", description: "Rejoignez l'écosystème CHEIKH$." },
        {
          title: "Miner",
          description: "Participez au système de mining disponible via la plateforme officielle.",
        },
        {
          title: "Gagner",
          description: "Accumulez les récompenses disponibles selon les règles du projet.",
        },
        {
          title: "Grandir",
          description: "Contribuez à la croissance de la communauté et de l'écosystème.",
        },
      ],
    },
    roadmap: {
      eyebrow: "EN CONSTRUCTION",
      title: "Feuille de route",
      description: "Un aperçu des axes de travail prévus pour le projet.",
      statusNote:
        "Les statuts de la feuille de route sont modifiables et ne doivent être mis à jour qu'après confirmation publique de l'avancement. Les étapes décrivent des projets, sans garantie de réalisation.",
      phaseLabel: "Phase",
      statuses: {
        completed: "Terminé",
        inProgress: "En cours",
        upcoming: "À venir",
      },
      phases: {
        foundation: "Fondations",
        community: "Communauté",
        ecosystem: "Écosystème",
        growth: "Croissance",
      },
      tasks: {
        tokenCreation: "Création du token",
        brandIdentity: "Identité CHEIKH$",
        officialChannels: "Canaux officiels",
        communityBuilding: "Développement de la communauté",
        miningDevelopment: "Développement du mining",
        rewardsSystem: "Système de récompenses",
        referralSystem: "Système de parrainage",
        platformDevelopment: "Développement de la plateforme",
        liquidity: "Liquidité",
        partnerships: "Partenariats",
        newFeatures: "Nouvelles fonctionnalités",
        ecosystemExpansion: "Expansion de l'écosystème",
        newIntegrations: "Nouvelles intégrations",
        internationalDevelopment: "Développement international",
        communityFeatures: "Fonctionnalités communautaires",
      },
    },
    community: {
      eyebrow: "CONSTRUIT ENSEMBLE",
      title: "Rejoignez la communauté CHEIKH$",
      description: "Suivez les annonces officielles et prenez part aux échanges.",
      channels: {
        x: { title: "X", description: "Suivez CHEIKH$ sur X." },
        telegramOfficial: {
          title: "Telegram officiel",
          description: "Recevez les annonces officielles et les actualités du projet.",
        },
        telegramCommunity: {
          title: "Communauté Telegram",
          description: "Parlez de CHEIKH$, partagez vos idées et échangez avec la communauté.",
        },
      },
      socialLabels: {
        x: "X",
        telegramOfficial: "Telegram officiel",
        telegramCommunity: "Communauté Telegram",
        discord: "Discord",
        youtube: "YouTube",
        tiktok: "TikTok",
        instagram: "Instagram",
        facebook: "Facebook",
        medium: "Medium",
        github: "GitHub",
        whitepaper: "Livre blanc",
      },
    },
    faq: {
      eyebrow: "BON À SAVOIR",
      title: "Questions fréquentes",
      description: "Des réponses claires sur CHEIKH$ et le token CHKH$.",
      items: [
        {
          question: "Qu'est-ce que CHEIKH$ ?",
          answer:
            "CHEIKH$ est un projet de token numérique communautaire sur TON, avec un écosystème axé sur le mining, les récompenses, le parrainage et la participation communautaire.",
        },
        {
          question: "Qu'est-ce que CHKH$ ?",
          answer: "CHKH$ est le symbole qui identifie le token CHEIKH$.",
        },
        {
          question: "Quelle blockchain CHEIKH$ utilise-t-il ?",
          answer: "CHEIKH$ est sur le réseau TON.",
        },
        {
          question: "Quelle est l'offre totale ?",
          answer: "L'offre totale annoncée est de {supply}.",
        },
        {
          question: "Comment commencer le mining ?",
          answer:
            "Utilisez le bot de mining ci-dessous. Consultez les canaux officiels pour connaître les règles et la disponibilité actuelles.",
          action: "mining",
        },
        {
          question: "Où trouver le Telegram officiel ?",
          answer: "Le canal officiel d'annonces est accessible ci-dessous.",
          action: "officialTelegram",
        },
        {
          question: "Où trouver la communauté officielle ?",
          answer: "Le groupe de discussion de la communauté est accessible ci-dessous.",
          action: "communityTelegram",
        },
        {
          question: "Où vérifier le contrat du token ?",
          answer: "Ouvrez le contrat sur TONviewer pour consulter ses informations on-chain.",
          action: "explorer",
        },
        {
          question: "Comment obtenir des CHKH$ ?",
          answer: "Utilisez uniquement une méthode communiquée via les canaux officiels du projet.",
          action: "buy",
        },
        {
          question: "Quels sont les risques ?",
          answer:
            "Les actifs numériques comportent des risques et peuvent perdre de la valeur. Ce site ne constitue pas un conseil financier, d'investissement ou juridique. Faites vos propres recherches.",
        },
      ],
      actionLabels: {
        mining: "Ouvrir le bot de mining",
        officialTelegram: "Ouvrir le Telegram officiel",
        communityTelegram: "Ouvrir le Telegram communautaire",
        explorer: "Vérifier sur TONviewer",
        buy: "Voir le lien officiel",
      },
    },
    disclaimerTitle: "Avertissement",
    disclaimer:
      "CHEIKH$ est un projet de token numérique communautaire. Les actifs liés aux cryptomonnaies comportent des risques et leur valeur peut varier. Le contenu de ce site ne constitue pas un conseil financier, d'investissement ou juridique. Effectuez vos propres recherches avant d'interagir avec des actifs numériques.",
    footer: {
      tagline: "Mine. Earn. Grow.",
      navigate: "Explorer",
      social: "Liens officiels",
      contract: "CHKH$ — TON",
      copyright: "Tous droits réservés.",
    },
  },
  es: {
    languageLabel: "Español",
    skipToContent: "Ir al contenido principal",
    nav: {
      primary: "Navegación principal",
      footer: "Navegación del pie de página",
      officialLinks: "Enlaces sociales oficiales",
      home: "Inicio",
      about: "Acerca de",
      tokenomics: "Tokenomics",
      roadmap: "Hoja de ruta",
      transparency: "Transparencia",
      community: "Comunidad",
      faq: "FAQ",
      language: "Elegir idioma",
      openMenu: "Abrir menú",
      closeMenu: "Cerrar menú",
    },
    actions: {
      startMining: "Empezar a minar",
      joinTelegram: "Unirse a Telegram",
      buyToken: "Comprar / obtener CHKH$",
      viewExplorer: "Ver en TONviewer",
      copyContract: "Copiar contrato",
      followX: "Seguir en X",
      joinOfficial: "Unirse al canal oficial",
      joinCommunity: "Unirse a la comunidad",
      copied: "¡Contrato copiado!",
      copyFailed: "No se pudo copiar. Copia la dirección manualmente.",
      openLink: "Abrir enlace",
    },
    hero: {
      eyebrow: "TOKEN COMUNITARIO EN TON",
      description: "Un ecosistema comunitario construido en torno a CHEIKH$, un token en la red TON.",
      networkLabel: "Construido en TON",
      scrollHint: "Desplázate para explorar",
      imageAlt: "Medallón metálico negro con un emblema de corona azul",
    },
    about: {
      eyebrow: "UN ECOSISTEMA IMPULSADO POR LA COMUNIDAD",
      title: "Acerca de CHEIKH$",
      description:
        "CHEIKH$ es un token comunitario desarrollado en torno a un ecosistema digital que combina minería, recompensas, referidos y participación comunitaria.",
      features: {
        mining: {
          title: "Minería",
          description:
            "Participa en el ecosistema y obtén recompensas según los mecanismos disponibles en la plataforma.",
        },
        rewards: {
          title: "Recompensas",
          description:
            "Un sistema diseñado para distribuir recompensas a la comunidad de forma progresiva.",
        },
        community: {
          title: "Comunidad",
          description: "La comunidad es el centro del desarrollo y la evolución de CHEIKH$.",
        },
      },
    },
    tokenomics: {
      eyebrow: "CLARIDAD POR DISEÑO",
      title: "Tokenomics",
      description: "Una distribución publicada del suministro del ecosistema CHEIKH$.",
      totalSupply: "Suministro total",
      allocation: "Distribución",
      total: "Total",
      allocationNames: {
        communityRewards: "Comunidad y recompensas",
        referralAirdrops: "Referidos y airdrops",
        liquidity: "Liquidez",
        ecosystemDevelopment: "Desarrollo del ecosistema",
        marketingPartnerships: "Marketing y alianzas",
        projectReserve: "Reserva del proyecto",
        teamFounder: "Equipo / fundador",
      },
      allocationDescriptions: {
        communityRewards: "Reservado para programas comunitarios y recompensas.",
        referralAirdrops: "Reservado para referidos y airdrops.",
        liquidity: "Asignado a liquidez.",
        ecosystemDevelopment: "Reservado para el desarrollo del ecosistema.",
        marketingPartnerships: "Reservado para marketing y alianzas.",
        projectReserve: "Mantenido como reserva del proyecto.",
        teamFounder: "Asignado al equipo y al fundador.",
      },
      note:
        "Las asignaciones y sus condiciones de uso pueden cambiar según la documentación oficial del proyecto. Cualquier cambio importante debe comunicarse públicamente.",
    },
    transparency: {
      eyebrow: "VERIFICA LOS DATOS",
      title: "Transparencia",
      description:
        "Aquí se muestran los datos clave del token para que puedas consultar el contrato directamente en la red TON.",
      network: "Red",
      token: "Token",
      symbol: "Símbolo",
      totalSupply: "Suministro total",
      contract: "Dirección del contrato",
      unavailable: "Datos no disponibles",
    },
    howItWorks: {
      eyebrow: "UN CAMINO SENCILLO",
      title: "Cómo funciona CHEIKH$",
      description: "Cuatro pasos sencillos para participar en el ecosistema CHEIKH$.",
      steps: [
        { title: "Únete", description: "Únete al ecosistema CHEIKH$." },
        {
          title: "Mina",
          description: "Participa en el sistema de minería disponible en la plataforma oficial.",
        },
        {
          title: "Gana",
          description: "Acumula las recompensas disponibles según las reglas del proyecto.",
        },
        {
          title: "Crece",
          description: "Contribuye al crecimiento de la comunidad y del ecosistema.",
        },
      ],
    },
    roadmap: {
      eyebrow: "EN DESARROLLO",
      title: "Hoja de ruta",
      description: "Un resumen de las áreas de trabajo previstas para el proyecto.",
      statusNote:
        "Los estados de la hoja de ruta se pueden modificar y solo deben actualizarse cuando el progreso se confirme públicamente. Las etapas describen planes, no una garantía de entrega.",
      phaseLabel: "Fase",
      statuses: {
        completed: "Completado",
        inProgress: "En curso",
        upcoming: "Próximamente",
      },
      phases: {
        foundation: "Fundamentos",
        community: "Comunidad",
        ecosystem: "Ecosistema",
        growth: "Crecimiento",
      },
      tasks: {
        tokenCreation: "Creación del token",
        brandIdentity: "Identidad de CHEIKH$",
        officialChannels: "Canales oficiales",
        communityBuilding: "Desarrollo de la comunidad",
        miningDevelopment: "Desarrollo de la minería",
        rewardsSystem: "Sistema de recompensas",
        referralSystem: "Sistema de referidos",
        platformDevelopment: "Desarrollo de la plataforma",
        liquidity: "Liquidez",
        partnerships: "Alianzas",
        newFeatures: "Nuevas funciones",
        ecosystemExpansion: "Expansión del ecosistema",
        newIntegrations: "Nuevas integraciones",
        internationalDevelopment: "Desarrollo internacional",
        communityFeatures: "Funciones comunitarias",
      },
    },
    community: {
      eyebrow: "CRECEMOS JUNTOS",
      title: "Únete a la comunidad CHEIKH$",
      description: "Sigue las novedades oficiales y participa en la conversación.",
      channels: {
        x: { title: "X", description: "Sigue a CHEIKH$ en X." },
        telegramOfficial: {
          title: "Telegram oficial",
          description: "Recibe anuncios oficiales y novedades del proyecto.",
        },
        telegramCommunity: {
          title: "Comunidad de Telegram",
          description: "Habla de CHEIKH$, comparte ideas y conecta con la comunidad.",
        },
      },
      socialLabels: {
        x: "X",
        telegramOfficial: "Telegram oficial",
        telegramCommunity: "Comunidad de Telegram",
        discord: "Discord",
        youtube: "YouTube",
        tiktok: "TikTok",
        instagram: "Instagram",
        facebook: "Facebook",
        medium: "Medium",
        github: "GitHub",
        whitepaper: "Documento técnico",
      },
    },
    faq: {
      eyebrow: "INFORMACIÓN ÚTIL",
      title: "Preguntas frecuentes",
      description: "Respuestas claras sobre CHEIKH$ y el token CHKH$.",
      items: [
        {
          question: "¿Qué es CHEIKH$?",
          answer:
            "CHEIKH$ es un proyecto de token digital comunitario en TON, con un ecosistema centrado en minería, recompensas, referidos y participación comunitaria.",
        },
        {
          question: "¿Qué es CHKH$?",
          answer: "CHKH$ es el símbolo que identifica al token CHEIKH$.",
        },
        {
          question: "¿Qué blockchain utiliza CHEIKH$?",
          answer: "CHEIKH$ funciona en la red TON.",
        },
        {
          question: "¿Cuál es el suministro total?",
          answer: "El suministro total indicado es de {supply}.",
        },
        {
          question: "¿Cómo puedo empezar a minar?",
          answer:
            "Usa el bot de minería enlazado abajo. Consulta los canales oficiales para conocer las reglas y la disponibilidad actuales.",
          action: "mining",
        },
        {
          question: "¿Dónde encuentro el Telegram oficial?",
          answer: "El canal oficial de anuncios está enlazado abajo.",
          action: "officialTelegram",
        },
        {
          question: "¿Dónde encuentro la comunidad oficial?",
          answer: "El chat de la comunidad está enlazado abajo.",
          action: "communityTelegram",
        },
        {
          question: "¿Dónde puedo verificar el contrato del token?",
          answer: "Abre el contrato en TONviewer para consultar sus datos en la cadena.",
          action: "explorer",
        },
        {
          question: "¿Cómo puedo obtener CHKH$?",
          answer: "Utiliza solo métodos compartidos en los canales oficiales del proyecto.",
          action: "buy",
        },
        {
          question: "¿Cuáles son los riesgos?",
          answer:
            "Los activos digitales conllevan riesgos y pueden perder valor. Este sitio no ofrece asesoramiento financiero, de inversión ni legal. Investiga por tu cuenta.",
        },
      ],
      actionLabels: {
        mining: "Abrir el bot de minería",
        officialTelegram: "Abrir Telegram oficial",
        communityTelegram: "Abrir Telegram de la comunidad",
        explorer: "Verificar en TONviewer",
        buy: "Ver enlace oficial",
      },
    },
    disclaimerTitle: "Aviso legal",
    disclaimer:
      "CHEIKH$ es un proyecto de token digital impulsado por la comunidad. Los criptoactivos conllevan riesgos y su valor puede cambiar. Nada en este sitio constituye asesoramiento financiero, de inversión ni legal. Investiga por tu cuenta antes de interactuar con activos digitales.",
    footer: {
      tagline: "Mine. Earn. Grow.",
      navigate: "Explorar",
      social: "Enlaces oficiales",
      contract: "CHKH$ — TON",
      copyright: "Todos los derechos reservados.",
    },
  },
  ar: {
    languageLabel: "العربية",
    skipToContent: "انتقل إلى المحتوى الرئيسي",
    nav: {
      primary: "التنقل الرئيسي",
      footer: "التنقل في التذييل",
      officialLinks: "روابط التواصل الرسمية",
      home: "الرئيسية",
      about: "عن المشروع",
      tokenomics: "اقتصاديات الرمز",
      roadmap: "خارطة الطريق",
      transparency: "الشفافية",
      community: "المجتمع",
      faq: "الأسئلة الشائعة",
      language: "اختر اللغة",
      openMenu: "فتح القائمة",
      closeMenu: "إغلاق القائمة",
    },
    actions: {
      startMining: "ابدأ التعدين",
      joinTelegram: "انضم إلى تيليجرام",
      buyToken: "شراء / الحصول على CHKH$",
      viewExplorer: "عرض على TONviewer",
      copyContract: "نسخ العقد",
      followX: "تابع على X",
      joinOfficial: "انضم إلى القناة الرسمية",
      joinCommunity: "انضم إلى المجتمع",
      copied: "تم نسخ العقد!",
      copyFailed: "تعذر النسخ. يرجى نسخ العنوان يدويًا.",
      openLink: "فتح الرابط",
    },
    hero: {
      eyebrow: "رمز مجتمعي على TON",
      description: "منظومة مجتمعية مبنية حول CHEIKH$، وهو رمز على شبكة TON.",
      networkLabel: "مبني على TON",
      scrollHint: "مرر لاستكشاف الموقع",
      imageAlt: "ميدالية معدنية سوداء تحمل شعار تاج أزرق",
    },
    about: {
      eyebrow: "منظومة يقودها المجتمع",
      title: "عن CHEIKH$",
      description:
        "CHEIKH$ رمز مجتمعي ضمن منظومة رقمية تجمع بين التعدين والمكافآت والإحالات والمشاركة المجتمعية.",
      features: {
        mining: {
          title: "التعدين",
          description: "شارك في المنظومة واحصل على مكافآت وفق الآليات المتاحة على المنصة.",
        },
        rewards: {
          title: "المكافآت",
          description: "نظام مصمم لتوزيع المكافآت على المجتمع تدريجيًا.",
        },
        community: {
          title: "المجتمع",
          description: "يقع المجتمع في صميم تطوير CHEIKH$ وتطوره.",
        },
      },
    },
    tokenomics: {
      eyebrow: "وضوح من البداية",
      title: "اقتصاديات الرمز",
      description: "توزيع معلن لإجمالي معروض منظومة CHEIKH$.",
      totalSupply: "إجمالي المعروض",
      allocation: "التوزيع",
      total: "الإجمالي",
      allocationNames: {
        communityRewards: "المجتمع والمكافآت",
        referralAirdrops: "الإحالات والتوزيعات",
        liquidity: "السيولة",
        ecosystemDevelopment: "تطوير المنظومة",
        marketingPartnerships: "التسويق والشراكات",
        projectReserve: "احتياطي المشروع",
        teamFounder: "الفريق / المؤسس",
      },
      allocationDescriptions: {
        communityRewards: "مخصص لبرامج المجتمع والمكافآت.",
        referralAirdrops: "مخصص للإحالات والتوزيعات المجانية.",
        liquidity: "مخصص للسيولة.",
        ecosystemDevelopment: "مخصص لتطوير المنظومة.",
        marketingPartnerships: "مخصص للتسويق والشراكات.",
        projectReserve: "محفوظ كاحتياطي للمشروع.",
        teamFounder: "مخصص للفريق والمؤسس.",
      },
      note:
        "قد تتغير التخصيصات وشروط استخدامها وفقًا للوثائق الرسمية للمشروع. وينبغي الإعلان عن أي تغيير جوهري للجمهور.",
    },
    transparency: {
      eyebrow: "تحقق من التفاصيل",
      title: "الشفافية",
      description: "تجد هنا بيانات الرمز الأساسية للتحقق من العقد مباشرة على شبكة TON.",
      network: "الشبكة",
      token: "الرمز",
      symbol: "الرمز المختصر",
      totalSupply: "إجمالي المعروض",
      contract: "عنوان العقد",
      unavailable: "البيانات غير متاحة",
    },
    howItWorks: {
      eyebrow: "خطوات بسيطة",
      title: "كيف يعمل CHEIKH$",
      description: "أربع خطوات بسيطة للمشاركة في منظومة CHEIKH$.",
      steps: [
        { title: "انضم", description: "انضم إلى منظومة CHEIKH$." },
        {
          title: "عدّن",
          description: "شارك في نظام التعدين المتاح عبر المنصة الرسمية.",
        },
        {
          title: "اكسب",
          description: "اجمع المكافآت المتاحة وفق قواعد المشروع.",
        },
        {
          title: "انمُ",
          description: "ساهم في نمو المجتمع والمنظومة.",
        },
      ],
    },
    roadmap: {
      eyebrow: "قيد التطوير",
      title: "خارطة الطريق",
      description: "نظرة عامة على مجالات العمل المخطط لها في المشروع.",
      statusNote:
        "يمكن تعديل حالات خارطة الطريق، وينبغي تحديثها بعد تأكيد التقدم علنًا فقط. تصف البنود خططًا ولا تمثل ضمانًا للتنفيذ.",
      phaseLabel: "المرحلة",
      statuses: {
        completed: "مكتمل",
        inProgress: "قيد التنفيذ",
        upcoming: "قادم",
      },
      phases: {
        foundation: "التأسيس",
        community: "المجتمع",
        ecosystem: "المنظومة",
        growth: "النمو",
      },
      tasks: {
        tokenCreation: "إنشاء الرمز",
        brandIdentity: "هوية CHEIKH$",
        officialChannels: "القنوات الرسمية",
        communityBuilding: "تطوير المجتمع",
        miningDevelopment: "تطوير التعدين",
        rewardsSystem: "نظام المكافآت",
        referralSystem: "نظام الإحالات",
        platformDevelopment: "تطوير المنصة",
        liquidity: "السيولة",
        partnerships: "الشراكات",
        newFeatures: "ميزات جديدة",
        ecosystemExpansion: "توسيع المنظومة",
        newIntegrations: "تكاملات جديدة",
        internationalDevelopment: "التطوير الدولي",
        communityFeatures: "ميزات مجتمعية",
      },
    },
    community: {
      eyebrow: "نبني معًا",
      title: "انضم إلى مجتمع CHEIKH$",
      description: "تابع التحديثات الرسمية وشارك في الحوار.",
      channels: {
        x: { title: "X", description: "تابع CHEIKH$ على X." },
        telegramOfficial: {
          title: "تيليجرام الرسمي",
          description: "تلقَّ الإعلانات الرسمية وتحديثات المشروع.",
        },
        telegramCommunity: {
          title: "مجتمع تيليجرام",
          description: "ناقش CHEIKH$ وشارك الأفكار وتواصل مع المجتمع.",
        },
      },
      socialLabels: {
        x: "X",
        telegramOfficial: "تيليجرام الرسمي",
        telegramCommunity: "مجتمع تيليجرام",
        discord: "Discord",
        youtube: "YouTube",
        tiktok: "TikTok",
        instagram: "Instagram",
        facebook: "Facebook",
        medium: "Medium",
        github: "GitHub",
        whitepaper: "الوثيقة التقنية",
      },
    },
    faq: {
      eyebrow: "معلومات مهمة",
      title: "الأسئلة الشائعة",
      description: "إجابات واضحة حول CHEIKH$ ورمز CHKH$.",
      items: [
        {
          question: "ما هو CHEIKH$؟",
          answer:
            "CHEIKH$ مشروع رمز رقمي مجتمعي على TON، وتتمحور منظومته حول التعدين والمكافآت والإحالات والمشاركة المجتمعية.",
        },
        {
          question: "ما هو CHKH$؟",
          answer: "CHKH$ هو الرمز المختصر المستخدم للتعريف برمز CHEIKH$.",
        },
        {
          question: "أي شبكة بلوكتشين يستخدم CHEIKH$؟",
          answer: "يعمل CHEIKH$ على شبكة TON.",
        },
        {
          question: "ما إجمالي المعروض؟",
          answer: "إجمالي المعروض المعلن هو {supply}.",
        },
        {
          question: "كيف أبدأ التعدين؟",
          answer: "استخدم بوت التعدين المرتبط أدناه. راجع القنوات الرسمية لمعرفة القواعد والتوفر الحاليين.",
          action: "mining",
        },
        {
          question: "أين أجد تيليجرام الرسمي؟",
          answer: "قناة الإعلانات الرسمية مرتبطة أدناه.",
          action: "officialTelegram",
        },
        {
          question: "أين أجد المجتمع الرسمي؟",
          answer: "مجموعة المجتمع مرتبطة أدناه.",
          action: "communityTelegram",
        },
        {
          question: "أين يمكنني التحقق من عقد الرمز؟",
          answer: "افتح العقد على TONviewer للاطلاع على بياناته على السلسلة.",
          action: "explorer",
        },
        {
          question: "كيف يمكنني الحصول على CHKH$؟",
          answer: "استخدم فقط الطرق المنشورة عبر القنوات الرسمية للمشروع.",
          action: "buy",
        },
        {
          question: "ما المخاطر؟",
          answer:
            "تنطوي الأصول الرقمية على مخاطر وقد تفقد قيمتها. لا يقدم هذا الموقع نصيحة مالية أو استثمارية أو قانونية. أجرِ بحثك الخاص.",
        },
      ],
      actionLabels: {
        mining: "فتح بوت التعدين",
        officialTelegram: "فتح تيليجرام الرسمي",
        communityTelegram: "فتح تيليجرام المجتمع",
        explorer: "التحقق على TONviewer",
        buy: "عرض الرابط الرسمي",
      },
    },
    disclaimerTitle: "إخلاء المسؤولية",
    disclaimer:
      "CHEIKH$ مشروع رمز رقمي يقوده المجتمع. تنطوي أصول العملات المشفرة على مخاطر وقد تتغير قيمتها. لا يشكل أي محتوى على هذا الموقع نصيحة مالية أو استثمارية أو قانونية. أجرِ بحثك الخاص قبل التعامل مع الأصول الرقمية.",
    footer: {
      tagline: "Mine. Earn. Grow.",
      navigate: "استكشف",
      social: "الروابط الرسمية",
      contract: "CHKH$ — TON",
      copyright: "جميع الحقوق محفوظة.",
    },
  },
  ru: {
    languageLabel: "Русский",
    skipToContent: "Перейти к основному содержимому",
    nav: {
      primary: "Основная навигация",
      footer: "Навигация в подвале",
      officialLinks: "Официальные социальные ссылки",
      home: "Главная",
      about: "О проекте",
      tokenomics: "Токеномика",
      roadmap: "Дорожная карта",
      transparency: "Прозрачность",
      community: "Сообщество",
      faq: "Вопросы",
      language: "Выбрать язык",
      openMenu: "Открыть меню",
      closeMenu: "Закрыть меню",
    },
    actions: {
      startMining: "Начать майнинг",
      joinTelegram: "Присоединиться в Telegram",
      buyToken: "Купить / получить CHKH$",
      viewExplorer: "Открыть в TONviewer",
      copyContract: "Скопировать контракт",
      followX: "Подписаться в X",
      joinOfficial: "Официальный канал",
      joinCommunity: "Присоединиться к сообществу",
      copied: "Адрес контракта скопирован!",
      copyFailed: "Не удалось скопировать. Скопируйте адрес вручную.",
      openLink: "Открыть ссылку",
    },
    hero: {
      eyebrow: "СООБЩЕСТВЕННЫЙ ТОКЕН В TON",
      description: "Экосистема сообщества вокруг CHEIKH$ — токена в сети TON.",
      networkLabel: "Создано на TON",
      scrollHint: "Прокрутите, чтобы узнать больше",
      imageAlt: "Черный металлический медальон с синей короной",
    },
    about: {
      eyebrow: "ЭКОСИСТЕМА СООБЩЕСТВА",
      title: "О CHEIKH$",
      description:
        "CHEIKH$ — это токен сообщества, развиваемый в рамках цифровой экосистемы с майнингом, наградами, реферальной системой и участием сообщества.",
      features: {
        mining: {
          title: "Майнинг",
          description:
            "Участвуйте в экосистеме и получайте награды согласно механизмам, доступным на платформе.",
        },
        rewards: {
          title: "Награды",
          description: "Система для постепенного распределения наград сообществу.",
        },
        community: {
          title: "Сообщество",
          description: "Сообщество находится в центре развития и эволюции CHEIKH$.",
        },
      },
    },
    tokenomics: {
      eyebrow: "ПРОЗРАЧНОСТЬ В ОСНОВЕ",
      title: "Токеномика",
      description: "Опубликованное распределение предложения экосистемы CHEIKH$.",
      totalSupply: "Общее предложение",
      allocation: "Распределение",
      total: "Итого",
      allocationNames: {
        communityRewards: "Сообщество и награды",
        referralAirdrops: "Реферальная программа и аирдропы",
        liquidity: "Ликвидность",
        ecosystemDevelopment: "Развитие экосистемы",
        marketingPartnerships: "Маркетинг и партнерства",
        projectReserve: "Резерв проекта",
        teamFounder: "Команда / основатель",
      },
      allocationDescriptions: {
        communityRewards: "Для программ сообщества и наград.",
        referralAirdrops: "Для реферальной программы и аирдропов.",
        liquidity: "Выделено для ликвидности.",
        ecosystemDevelopment: "Для развития экосистемы.",
        marketingPartnerships: "Для маркетинга и партнерств.",
        projectReserve: "Резерв проекта.",
        teamFounder: "Выделено команде и основателю.",
      },
      note:
        "Распределение и условия использования могут меняться согласно официальной документации проекта. О существенных изменениях следует сообщать публично.",
    },
    transparency: {
      eyebrow: "ПРОВЕРЬТЕ ДАННЫЕ",
      title: "Прозрачность",
      description:
        "Здесь приведены основные сведения о токене, чтобы вы могли проверить контракт напрямую в сети TON.",
      network: "Сеть",
      token: "Токен",
      symbol: "Символ",
      totalSupply: "Общее предложение",
      contract: "Адрес контракта",
      unavailable: "Данные недоступны",
    },
    howItWorks: {
      eyebrow: "ПРОСТОЙ ПУТЬ",
      title: "Как работает CHEIKH$",
      description: "Четыре простых шага для участия в экосистеме CHEIKH$.",
      steps: [
        { title: "Вступить", description: "Присоединитесь к экосистеме CHEIKH$." },
        {
          title: "Майнить",
          description: "Участвуйте в системе майнинга на официальной платформе.",
        },
        {
          title: "Получать",
          description: "Накапливайте доступные награды по правилам проекта.",
        },
        {
          title: "Развивать",
          description: "Вносите вклад в развитие сообщества и экосистемы.",
        },
      ],
    },
    roadmap: {
      eyebrow: "В РАЗРАБОТКЕ",
      title: "Дорожная карта",
      description: "Обзор запланированных направлений работы проекта.",
      statusNote:
        "Статусы дорожной карты можно менять; обновляйте их только после публичного подтверждения прогресса. Этапы обозначают планы, а не гарантию реализации.",
      phaseLabel: "Этап",
      statuses: {
        completed: "Завершено",
        inProgress: "В работе",
        upcoming: "Предстоит",
      },
      phases: {
        foundation: "Основа",
        community: "Сообщество",
        ecosystem: "Экосистема",
        growth: "Рост",
      },
      tasks: {
        tokenCreation: "Создание токена",
        brandIdentity: "Идентичность CHEIKH$",
        officialChannels: "Официальные каналы",
        communityBuilding: "Развитие сообщества",
        miningDevelopment: "Развитие майнинга",
        rewardsSystem: "Система наград",
        referralSystem: "Реферальная система",
        platformDevelopment: "Развитие платформы",
        liquidity: "Ликвидность",
        partnerships: "Партнерства",
        newFeatures: "Новые функции",
        ecosystemExpansion: "Расширение экосистемы",
        newIntegrations: "Новые интеграции",
        internationalDevelopment: "Международное развитие",
        communityFeatures: "Функции сообщества",
      },
    },
    community: {
      eyebrow: "СОЗДАЕМ ВМЕСТЕ",
      title: "Присоединяйтесь к сообществу CHEIKH$",
      description: "Следите за официальными новостями и участвуйте в обсуждениях.",
      channels: {
        x: { title: "X", description: "Подписывайтесь на CHEIKH$ в X." },
        telegramOfficial: {
          title: "Официальный Telegram",
          description: "Получайте официальные объявления и новости проекта.",
        },
        telegramCommunity: {
          title: "Сообщество в Telegram",
          description: "Обсуждайте CHEIKH$, делитесь идеями и общайтесь с участниками.",
        },
      },
      socialLabels: {
        x: "X",
        telegramOfficial: "Официальный Telegram",
        telegramCommunity: "Сообщество в Telegram",
        discord: "Discord",
        youtube: "YouTube",
        tiktok: "TikTok",
        instagram: "Instagram",
        facebook: "Facebook",
        medium: "Medium",
        github: "GitHub",
        whitepaper: "Документация",
      },
    },
    faq: {
      eyebrow: "ПОЛЕЗНО ЗНАТЬ",
      title: "Часто задаваемые вопросы",
      description: "Краткие ответы о CHEIKH$ и токене CHKH$.",
      items: [
        {
          question: "Что такое CHEIKH$?",
          answer:
            "CHEIKH$ — это проект цифрового токена сообщества в сети TON, экосистема которого связана с майнингом, наградами, реферальной программой и участием сообщества.",
        },
        {
          question: "Что такое CHKH$?",
          answer: "CHKH$ — это обозначение токена CHEIKH$.",
        },
        {
          question: "Какой блокчейн использует CHEIKH$?",
          answer: "CHEIKH$ работает в сети TON.",
        },
        {
          question: "Каково общее предложение?",
          answer: "Указанное общее предложение — {supply}.",
        },
        {
          question: "Как начать майнинг?",
          answer: "Используйте ссылку на бот ниже. Актуальные правила и доступность уточняйте в официальных каналах.",
          action: "mining",
        },
        {
          question: "Где найти официальный Telegram?",
          answer: "Ссылка на официальный канал объявлений приведена ниже.",
          action: "officialTelegram",
        },
        {
          question: "Где найти сообщество?",
          answer: "Ссылка на чат сообщества приведена ниже.",
          action: "communityTelegram",
        },
        {
          question: "Где проверить контракт токена?",
          answer: "Откройте контракт в TONviewer, чтобы посмотреть данные в блокчейне.",
          action: "explorer",
        },
        {
          question: "Как получить CHKH$?",
          answer: "Используйте только способы, опубликованные в официальных каналах проекта.",
          action: "buy",
        },
        {
          question: "Какие есть риски?",
          answer:
            "Цифровые активы связаны с риском и могут потерять в цене. Сайт не является финансовой, инвестиционной или юридической консультацией. Изучите вопрос самостоятельно.",
        },
      ],
      actionLabels: {
        mining: "Открыть бот для майнинга",
        officialTelegram: "Открыть официальный Telegram",
        communityTelegram: "Открыть Telegram сообщества",
        explorer: "Проверить в TONviewer",
        buy: "Открыть официальную ссылку",
      },
    },
    disclaimerTitle: "Отказ от ответственности",
    disclaimer:
      "CHEIKH$ — это проект цифрового токена сообщества. Криптоактивы связаны с риском, а их стоимость может меняться. Информация на этом сайте не является финансовой, инвестиционной или юридической консультацией. Прежде чем взаимодействовать с цифровыми активами, изучите вопрос самостоятельно.",
    footer: {
      tagline: "Mine. Earn. Grow.",
      navigate: "Разделы",
      social: "Официальные ссылки",
      contract: "CHKH$ — TON",
      copyright: "Все права защищены.",
    },
  },
};