// Set this once the official custom domain is confirmed.
export const WEBSITE_URL = "";

export const X_URL = "https://x.com/cheikhtoken?s=11";
export const TELEGRAM_OFFICIAL_URL = "https://t.me/+4jU2bP7NL1Y4MDY8";
export const TELEGRAM_COMMUNITY_URL = "https://t.me/+1Bex7CNnUX5jMjI0";
export const TELEGRAM_BOT_USERNAME = "@cheikhminer_bot";
export const TELEGRAM_BOT_URL = TELEGRAM_BOT_USERNAME
  ? `https://t.me/${TELEGRAM_BOT_USERNAME.replace(/^@/, "")}`
  : "";
export const DISCORD_URL = "";
export const YOUTUBE_URL = "";
export const TIKTOK_URL = "";
export const INSTAGRAM_URL = "";
export const FACEBOOK_URL = "";
export const MEDIUM_URL = "";
export const GITHUB_URL = "";
export const WHITEPAPER_URL = "";
export const BUY_TOKEN_URL = "";

export const TON_CONTRACT_ADDRESS =
  "0:0494d83a6ed22265a643a7f72334419cf04aec7eb50cd54ceafb4b8ea604b597";
export const TON_EXPLORER_URL =
  "https://tonviewer.com/0:0494d83a6ed22265a643a7f72334419cf04aec7eb50cd54ceafb4b8ea604b597";

export const SITE_CONFIG = {
  projectName: "CHEIKH$",
  tokenName: "CHEIKH$",
  symbol: "CHKH$",
  network: "TON",
  totalSupply: "5,000,000,000",
  slogan: "Mine. Earn. Grow.",
  websiteUrl: WEBSITE_URL,
} as const;

export const SOCIAL_LINKS = {
  x: X_URL,
  telegramOfficial: TELEGRAM_OFFICIAL_URL,
  telegramCommunity: TELEGRAM_COMMUNITY_URL,
  telegramBotUsername: TELEGRAM_BOT_USERNAME,
  telegramBot: TELEGRAM_BOT_URL,
  discord: DISCORD_URL,
  youtube: YOUTUBE_URL,
  tiktok: TIKTOK_URL,
  instagram: INSTAGRAM_URL,
  facebook: FACEBOOK_URL,
  medium: MEDIUM_URL,
  github: GITHUB_URL,
} as const;

export const RESOURCE_LINKS = {
  whitepaper: WHITEPAPER_URL,
} as const;

export const TOKEN_CONFIG = {
  contractAddress: TON_CONTRACT_ADDRESS,
  explorerUrl: TON_EXPLORER_URL,
  buyUrl: BUY_TOKEN_URL,
} as const;

export const LANGUAGE_CONFIG = {
  defaultLanguage: "en",
  supportedLanguages: ["fr", "en", "es", "ar", "ru"],
} as const;

export type Language = (typeof LANGUAGE_CONFIG.supportedLanguages)[number];

export const TOKEN_ALLOCATIONS = [
  {
    id: "communityRewards",
    percent: 40,
    amount: "2,000,000,000",
    color: "#1977ff",
  },
  {
    id: "referralAirdrops",
    percent: 15,
    amount: "750,000,000",
    color: "#32c8ff",
  },
  {
    id: "liquidity",
    percent: 15,
    amount: "750,000,000",
    color: "#4d69ff",
  },
  {
    id: "ecosystemDevelopment",
    percent: 10,
    amount: "500,000,000",
    color: "#25a8d8",
  },
  {
    id: "marketingPartnerships",
    percent: 5,
    amount: "250,000,000",
    color: "#8295ff",
  },
  {
    id: "projectReserve",
    percent: 10,
    amount: "500,000,000",
    color: "#1873b9",
  },
  {
    id: "teamFounder",
    percent: 5,
    amount: "250,000,000",
    color: "#83dcff",
  },
] as const;

export type AllocationId = (typeof TOKEN_ALLOCATIONS)[number]["id"];

// UPCOMING is the conservative default until the team confirms phase progress publicly.
export const ROADMAP_CONFIG = [
  {
    id: "foundation",
    number: "01",
    status: "upcoming",
    tasks: ["tokenCreation", "brandIdentity", "officialChannels", "communityBuilding"],
  },
  {
    id: "community",
    number: "02",
    status: "upcoming",
    tasks: ["miningDevelopment", "rewardsSystem", "referralSystem", "communityBuilding"],
  },
  {
    id: "ecosystem",
    number: "03",
    status: "upcoming",
    tasks: ["platformDevelopment", "liquidity", "partnerships", "newFeatures"],
  },
  {
    id: "growth",
    number: "04",
    status: "upcoming",
    tasks: ["ecosystemExpansion", "newIntegrations", "internationalDevelopment", "communityFeatures"],
  },
] as const;

export type RoadmapPhaseId = (typeof ROADMAP_CONFIG)[number]["id"];
export type RoadmapStatus = "completed" | "inProgress" | "upcoming";
export type RoadmapTaskKey = (typeof ROADMAP_CONFIG)[number]["tasks"][number];