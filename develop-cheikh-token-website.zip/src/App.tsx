import { useEffect, useRef, useState, type CSSProperties } from "react";
import {
  LANGUAGE_CONFIG,
  ROADMAP_CONFIG,
  RESOURCE_LINKS,
  SITE_CONFIG,
  SOCIAL_LINKS,
  TOKEN_ALLOCATIONS,
  TOKEN_CONFIG,
  type Language,
  type RoadmapStatus,
} from "./config/site";
import { translations, type FAQAction, type Translation } from "./i18n/translations";

const HEADER_LINKS = [
  { href: "#home", labelKey: "home" },
  { href: "#about", labelKey: "about" },
  { href: "#tokenomics", labelKey: "tokenomics" },
  { href: "#roadmap", labelKey: "roadmap" },
  { href: "#transparency", labelKey: "transparency" },
  { href: "#community", labelKey: "community" },
] as const;

const FOOTER_LINKS = [...HEADER_LINKS, { href: "#faq", labelKey: "faq" }] as const;

const LANGUAGE_OPTIONS: { value: Language; flag: string; name: string }[] = [
  { value: "fr", flag: "🇫🇷", name: "Français" },
  { value: "en", flag: "🇬🇧", name: "English" },
  { value: "es", flag: "🇪🇸", name: "Español" },
  { value: "ar", flag: "🇸🇦", name: "العربية" },
  { value: "ru", flag: "🇷🇺", name: "Русский" },
];

const COMMUNITY_LINKS = ([
  { id: "x", href: SOCIAL_LINKS.x, actionKey: "followX" },
  { id: "telegramOfficial", href: SOCIAL_LINKS.telegramOfficial, actionKey: "joinOfficial" },
  {
    id: "telegramCommunity",
    href: SOCIAL_LINKS.telegramCommunity,
    actionKey: "joinCommunity",
  },
] as const).filter((link) => link.href.trim().length > 0);

const FOOTER_SOCIAL_LINKS = [
  { id: "x", href: SOCIAL_LINKS.x, labelKey: "x" },
  { id: "telegramOfficial", href: SOCIAL_LINKS.telegramOfficial, labelKey: "telegramOfficial" },
  {
    id: "telegramCommunity",
    href: SOCIAL_LINKS.telegramCommunity,
    labelKey: "telegramCommunity",
  },
  { id: "discord", href: SOCIAL_LINKS.discord, labelKey: "discord" },
  { id: "youtube", href: SOCIAL_LINKS.youtube, labelKey: "youtube" },
  { id: "tiktok", href: SOCIAL_LINKS.tiktok, labelKey: "tiktok" },
  { id: "instagram", href: SOCIAL_LINKS.instagram, labelKey: "instagram" },
  { id: "facebook", href: SOCIAL_LINKS.facebook, labelKey: "facebook" },
  { id: "medium", href: SOCIAL_LINKS.medium, labelKey: "medium" },
  { id: "github", href: SOCIAL_LINKS.github, labelKey: "github" },
  { id: "whitepaper", href: RESOURCE_LINKS.whitepaper, labelKey: "whitepaper" },
].filter((link) => link.href.trim().length > 0);

function CrownMark({ className = "" }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 42 42"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="21" cy="21" r="18.25" stroke="currentColor" strokeOpacity=".28" />
      <path
        d="m9.5 15 7.4 6.2L21 10l4.1 11.2 7.4-6.2-2.4 15H11.9l-2.4-15Z"
        fill="currentColor"
      />
      <path d="M13 33h16" stroke="currentColor" strokeLinecap="round" strokeWidth="1.5" />
      <circle cx="9.5" cy="15" r="1.7" fill="currentColor" />
      <circle cx="21" cy="10" r="1.7" fill="currentColor" />
      <circle cx="32.5" cy="15" r="1.7" fill="currentColor" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg aria-hidden="true" className="arrow-icon" fill="none" viewBox="0 0 20 20">
      <path
        d="M3.5 10h12m-5-5 5 5-5 5"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
    </svg>
  );
}

function FeatureIcon({ name }: { name: "mining" | "rewards" | "community" }) {
  const paths = {
    mining: (
      <>
        <path d="m6 15 8-8m-9 2 4 4m5-8 4 4M5 19l4-4" />
        <path d="M13.5 5.5 17 9" />
      </>
    ),
    rewards: (
      <>
        <path d="M12 3.5 14.3 8l5 .7-3.6 3.5.9 5-4.6-2.4-4.6 2.4.9-5-3.6-3.5 5-.7L12 3.5Z" />
        <path d="M7 20h10" />
      </>
    ),
    community: (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3.5 19v-1.5A5.5 5.5 0 0 1 9 12h.5a5.5 5.5 0 0 1 5.5 5.5V19" />
        <path d="M15.5 5.3a3 3 0 0 1 0 5.8m2.8 2.4a5.2 5.2 0 0 1 2.2 4.2V19" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      className="feature-icon"
      fill="none"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.5"
      viewBox="0 0 24 24"
    >
      {paths[name]}
    </svg>
  );
}

function ChannelIcon({ name }: { name: "x" | "telegramOfficial" | "telegramCommunity" }) {
  if (name === "x") {
    return (
      <svg aria-hidden="true" className="channel-icon" fill="currentColor" viewBox="0 0 24 24">
        <path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3l-5-7.5L5.4 22H2.2l7.3-8.4L1.8 2h6.4l4.5 6.9L18.9 2Zm-1.1 17.9h1.7L7.3 4H5.5l12.3 15.9Z" />
      </svg>
    );
  }

  return (
    <svg aria-hidden="true" className="channel-icon" fill="none" viewBox="0 0 24 24">
      <path
        d="m3.2 11.2 16.2-6.3c.8-.3 1.5.2 1.2 1.4l-2.8 13.2c-.2.9-.8 1.1-1.5.7l-4.4-3.2-2.1 2c-.2.2-.4.4-.8.4l.3-4.5 8.2-7.4c.4-.3-.1-.5-.6-.2l-10.1 6.3-4.4-1.4c-1-.3-1-1.1.8-1.8Z"
        fill="currentColor"
      />
    </svg>
  );
}

function ExternalAction({
  href,
  label,
  variant = "primary",
  className = "",
  arrow = true,
}: {
  href: string;
  label: string;
  variant?: "primary" | "secondary" | "text";
  className?: string;
  arrow?: boolean;
}) {
  if (!href.trim()) return null;

  return (
    <a
      className={`button button--${variant} ${className}`.trim()}
      href={href}
      rel="noopener noreferrer"
      target="_blank"
    >
      <span>{label}</span>
      {arrow && <ArrowIcon />}
    </a>
  );
}

function LanguageSelector({
  language,
  onChange,
  label,
}: {
  language: Language;
  onChange: (language: Language) => void;
  label: string;
}) {
  return (
    <label className="language-selector">
      <span className="visually-hidden">{label}</span>
      <select
        aria-label={label}
        onChange={(event) => onChange(event.currentTarget.value as Language)}
        value={language}
      >
        {LANGUAGE_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.flag} {option.name}
          </option>
        ))}
      </select>
      <span aria-hidden="true" className="language-caret">
        ▾
      </span>
    </label>
  );
}

function Header({
  copy,
  language,
  onLanguageChange,
}: {
  copy: Translation;
  language: Language;
  onLanguageChange: (language: Language) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!menuOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [menuOpen]);

  return (
    <header className="site-header">
      <div className="header-inner page-container">
        <a
          aria-label={`${SITE_CONFIG.projectName} - ${copy.nav.home}`}
          className="brand-lockup"
          href="#home"
          onClick={() => setMenuOpen(false)}
        >
          <CrownMark className="brand-mark" />
          <span className="brand-name" dir="ltr">CHEIKH<span>$</span></span>
        </a>

        <nav
          aria-label={copy.nav.primary}
          className={`primary-nav ${menuOpen ? "is-open" : ""}`}
          id="mobile-navigation"
        >
          {HEADER_LINKS.map((link) => (
            <a href={link.href} key={link.href} onClick={() => setMenuOpen(false)}>
              {copy.nav[link.labelKey]}
            </a>
          ))}
        </nav>

        <div className="header-actions">
          <LanguageSelector
            label={copy.nav.language}
            language={language}
            onChange={onLanguageChange}
          />
          <ExternalAction
            className="header-start"
            href={SOCIAL_LINKS.telegramBot}
            label={copy.actions.startMining}
            variant="primary"
          />
          <button
            aria-controls="mobile-navigation"
            aria-expanded={menuOpen}
            aria-label={menuOpen ? copy.nav.closeMenu : copy.nav.openMenu}
            className={`menu-toggle ${menuOpen ? "is-open" : ""}`}
            onClick={() => setMenuOpen((open) => !open)}
            type="button"
          >
            <span />
            <span />
          </button>
        </div>
      </div>
    </header>
  );
}

function HeroSection({ copy }: { copy: Translation }) {
  return (
    <section aria-labelledby="hero-title" className="hero" id="home">
      <img
        alt={copy.hero.imageAlt}
        className="hero-art"
        fetchPriority="high"
        src="/images/chkh-coin-hero.jpg"
      />
      <div aria-hidden="true" className="hero-scrim" />
      <div aria-hidden="true" className="hero-ambient" />
      <div className="hero-inner page-container">
        <div className="hero-copy">
          <p className="eyebrow hero-eyebrow">
            <span aria-hidden="true" className="eyebrow-dot" />
            {copy.hero.eyebrow}
          </p>
          <h1 dir="ltr" id="hero-title">
            CHEIKH<span>$</span>
          </h1>
          <div className="hero-symbol-row">
            <span className="hero-symbol" dir="ltr">{SITE_CONFIG.symbol}</span>
            <span aria-hidden="true" className="hero-symbol-divider" />
            <span className="hero-network">{copy.hero.networkLabel}</span>
          </div>
          <p className="hero-slogan"><bdi dir="ltr">{SITE_CONFIG.slogan}</bdi></p>
          <p className="hero-description">{copy.hero.description}</p>
          <div className="hero-actions">
            <ExternalAction
              href={SOCIAL_LINKS.telegramBot}
              label={copy.actions.startMining}
              variant="primary"
            />
            <ExternalAction
              href={SOCIAL_LINKS.telegramOfficial}
              label={copy.actions.joinTelegram}
              variant="secondary"
            />
            <ExternalAction
              href={TOKEN_CONFIG.buyUrl}
              label={copy.actions.buyToken}
              variant="text"
            />
          </div>
        </div>
      </div>
      <a aria-label={copy.hero.scrollHint} className="scroll-cue" href="#about">
        <span aria-hidden="true" className="scroll-cue-line" />
        <span>{copy.hero.scrollHint}</span>
      </a>
    </section>
  );
}

function SectionHeading({
  id,
  eyebrow,
  title,
  description,
}: {
  id?: string;
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="section-heading">
      <p className="eyebrow">{eyebrow}</p>
      <h2 id={id}>{title}</h2>
      {description && <p className="section-description">{description}</p>}
    </div>
  );
}

function AboutSection({ copy }: { copy: Translation }) {
  const features = [
    { id: "mining", icon: "mining" },
    { id: "rewards", icon: "rewards" },
    { id: "community", icon: "community" },
  ] as const;

  return (
    <section aria-labelledby="about-title" className="section about-section" id="about">
      <div className="page-container">
        <div className="section-heading section-heading--wide">
          <p className="eyebrow">{copy.about.eyebrow}</p>
          <h2 id="about-title">{copy.about.title}</h2>
          <p className="section-description">{copy.about.description}</p>
        </div>
        <div className="feature-grid">
          {features.map(({ id, icon }, index) => {
            const feature = copy.about.features[id];
            return (
              <article className="feature-item" key={id}>
                <div className="feature-topline">
                  <span className="feature-index">0{index + 1}</span>
                  <FeatureIcon name={icon} />
                </div>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function TokenomicsSection({ copy }: { copy: Translation }) {
  let currentAngle = 0;
  const segments = TOKEN_ALLOCATIONS.map((allocation) => {
    const start = currentAngle;
    currentAngle += allocation.percent * 3.6;
    return `${allocation.color} ${start}deg ${currentAngle}deg`;
  }).join(", ");
  const chartStyle = { "--allocation-chart": `conic-gradient(${segments})` } as CSSProperties;

  return (
    <section aria-labelledby="tokenomics-title" className="section tokenomics-section" id="tokenomics">
      <div className="page-container">
        <div className="section-heading section-heading--wide">
          <p className="eyebrow">{copy.tokenomics.eyebrow}</p>
          <h2 id="tokenomics-title">{copy.tokenomics.title}</h2>
          <p className="section-description">{copy.tokenomics.description}</p>
        </div>

        <div className="tokenomics-layout">
          <div className="tokenomics-visual">
            <p className="mini-label">{copy.tokenomics.totalSupply}</p>
            <div
              aria-label={`${copy.tokenomics.totalSupply}: ${SITE_CONFIG.totalSupply} ${SITE_CONFIG.symbol}`}
              className="allocation-chart"
              role="img"
              style={chartStyle}
            >
              <div className="allocation-chart-center">
                <span>{copy.tokenomics.totalSupply}</span>
                <strong dir="ltr">{SITE_CONFIG.totalSupply}</strong>
                <span dir="ltr">{SITE_CONFIG.symbol}</span>
              </div>
            </div>
            <div className="visual-caption">
              <span aria-hidden="true" className="visual-caption-mark" />
              <span>{copy.tokenomics.allocation}</span>
            </div>
          </div>

          <div className="allocation-list-wrap">
            <ul className="allocation-list">
              {TOKEN_ALLOCATIONS.map((allocation) => (
                <li
                  className="allocation-item"
                  key={allocation.id}
                  style={{ "--allocation-color": allocation.color } as CSSProperties}
                >
                  <span aria-hidden="true" className="allocation-swatch" />
                  <div className="allocation-copy">
                    <h3>{copy.tokenomics.allocationNames[allocation.id]}</h3>
                    <p>{copy.tokenomics.allocationDescriptions[allocation.id]}</p>
                  </div>
                  <span className="allocation-percent">{allocation.percent}%</span>
                  <span className="allocation-amount" dir="ltr">
                    {allocation.amount} <small>{SITE_CONFIG.symbol}</small>
                  </span>
                </li>
              ))}
            </ul>
            <div className="allocation-total">
              <span>{copy.tokenomics.total}</span>
              <strong>100%</strong>
              <strong dir="ltr">
                {SITE_CONFIG.totalSupply} <small>{SITE_CONFIG.symbol}</small>
              </strong>
            </div>
          </div>
        </div>

        <p className="tokenomics-note">
          <span aria-hidden="true">i</span>
          {copy.tokenomics.note}
        </p>
      </div>
    </section>
  );
}

function fallbackCopy(text: string) {
  const field = document.createElement("textarea");
  field.value = text;
  field.setAttribute("readonly", "");
  field.setAttribute("aria-hidden", "true");
  field.tabIndex = -1;
  field.style.position = "fixed";
  field.style.opacity = "0";
  field.style.pointerEvents = "none";
  document.body.appendChild(field);
  try {
    field.select();
    if (!document.execCommand("copy")) throw new Error("Clipboard unavailable");
  } finally {
    document.body.removeChild(field);
  }
}

function TransparencySection({ copy }: { copy: Translation }) {
  const [copyState, setCopyState] = useState<"copied" | "failed" | null>(null);
  const timerRef = useRef<number | null>(null);
  const contract = TOKEN_CONFIG.contractAddress;

  useEffect(() => () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
  }, []);

  async function handleCopy() {
    try {
      if (navigator.clipboard?.writeText && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(contract);
        } catch {
          fallbackCopy(contract);
        }
      } else {
        fallbackCopy(contract);
      }
      setCopyState("copied");
    } catch {
      setCopyState("failed");
    }

    if (timerRef.current) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => setCopyState(null), 2400);
  }

  const facts = [
    { label: copy.transparency.network, value: SITE_CONFIG.network },
    { label: copy.transparency.token, value: SITE_CONFIG.tokenName },
    { label: copy.transparency.symbol, value: SITE_CONFIG.symbol },
    {
      label: copy.transparency.totalSupply,
      value: `${SITE_CONFIG.totalSupply} ${SITE_CONFIG.symbol}`,
    },
  ];

  return (
    <section
      aria-labelledby="transparency-title"
      className="section transparency-section"
      id="transparency"
    >
      <div className="page-container transparency-layout">
        <div className="transparency-intro">
          <SectionHeading
            description={copy.transparency.description}
            eyebrow={copy.transparency.eyebrow}
            id="transparency-title"
            title={copy.transparency.title}
          />
          <div className="transparency-links">
            <ExternalAction
              href={TOKEN_CONFIG.explorerUrl}
              label={copy.actions.viewExplorer}
              variant="primary"
            />
          </div>
        </div>

        <div className="transparency-content">
          <dl className="transparency-facts">
            {facts.map((fact) => (
              <div className="transparency-fact" key={fact.label}>
                <dt>{fact.label}</dt>
                <dd><bdi dir="auto">{fact.value || copy.transparency.unavailable}</bdi></dd>
              </div>
            ))}
          </dl>

          <div className="contract-block">
            <div className="contract-heading">
              <span className="contract-label">{copy.transparency.contract}</span>
              <span aria-hidden="true" className="network-mark">
                <span /> TON
              </span>
            </div>
            <code className="contract-address" dir="ltr">
              {contract || copy.transparency.unavailable}
            </code>
            <div className="contract-actions">
              {contract && (
                <button className="button button--secondary copy-button" onClick={handleCopy} type="button">
                  <span>{copy.actions.copyContract}</span>
                  <svg aria-hidden="true" fill="none" viewBox="0 0 20 20">
                    <rect height="11.5" rx="1.5" stroke="currentColor" strokeWidth="1.4" width="9" x="7.5" y="6" />
                    <path d="M12.5 3.5h-7A1.5 1.5 0 0 0 4 5v9" stroke="currentColor" strokeLinecap="round" strokeWidth="1.4" />
                  </svg>
                </button>
              )}
              {TOKEN_CONFIG.explorerUrl && (
                <ExternalAction
                  arrow={false}
                  className="contract-explorer-link"
                  href={TOKEN_CONFIG.explorerUrl}
                  label={copy.actions.viewExplorer}
                  variant="text"
                />
              )}
            </div>
            <p aria-live="polite" className={`copy-feedback ${copyState ? "is-visible" : ""}`}>
              {copyState === "copied" ? copy.actions.copied : ""}
              {copyState === "failed" ? copy.actions.copyFailed : ""}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection({ copy }: { copy: Translation }) {
  return (
    <section aria-labelledby="how-title" className="section how-section" id="how-it-works">
      <div className="page-container">
        <SectionHeading
          description={copy.howItWorks.description}
          eyebrow={copy.howItWorks.eyebrow}
          id="how-title"
          title={copy.howItWorks.title}
        />
        <ol className="steps-list">
          {copy.howItWorks.steps.map((step, index) => (
            <li className="step-item" key={step.title}>
              <div className="step-number-row">
                <span className="step-number">0{index + 1}</span>
                <span aria-hidden="true" className="step-line" />
              </div>
              <h3>{step.title}</h3>
              <p>{step.description}</p>
            </li>
          ))}
        </ol>
        <div className="steps-action">
          <ExternalAction
            href={SOCIAL_LINKS.telegramBot}
            label={copy.actions.startMining}
            variant="secondary"
          />
        </div>
      </div>
    </section>
  );
}

function RoadmapSection({ copy }: { copy: Translation }) {
  return (
    <section aria-labelledby="roadmap-title" className="section roadmap-section" id="roadmap">
      <div className="page-container">
        <div className="roadmap-heading-row">
          <SectionHeading
            description={copy.roadmap.description}
            eyebrow={copy.roadmap.eyebrow}
            id="roadmap-title"
            title={copy.roadmap.title}
          />
          <p className="roadmap-note">{copy.roadmap.statusNote}</p>
        </div>
        <div className="roadmap-grid">
          {ROADMAP_CONFIG.map((phase) => {
            const content = copy.roadmap.phases[phase.id];
            const status = phase.status as RoadmapStatus;
            return (
              <article className="roadmap-phase" key={phase.id}>
                <div className="roadmap-phase-top">
                  <span className="roadmap-phase-number">{copy.roadmap.phaseLabel} {phase.number}</span>
                  <span className={`roadmap-status roadmap-status--${status}`}>
                    <span aria-hidden="true" />
                    {copy.roadmap.statuses[status]}
                  </span>
                </div>
                <h3>{content}</h3>
                <ul>
                  {phase.tasks.map((task) => (
                    <li key={`${phase.id}-${task}`}>{copy.roadmap.tasks[task]}</li>
                  ))}
                </ul>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function CommunitySection({ copy }: { copy: Translation }) {
  return (
    <section aria-labelledby="community-title" className="section community-section" id="community">
      <div className="page-container">
        <div className="community-heading">
          <SectionHeading
            description={copy.community.description}
            eyebrow={copy.community.eyebrow}
            id="community-title"
            title={copy.community.title}
          />
        </div>
        <div className="community-grid">
          {COMMUNITY_LINKS.map((link) => {
            const channel = copy.community.channels[link.id];
            return (
              <a
                className="community-card"
                href={link.href}
                key={link.id}
                rel="noopener noreferrer"
                target="_blank"
              >
                <div className="community-card-top">
                  <span className="community-icon-wrap">
                    <ChannelIcon name={link.id} />
                  </span>
                  <ArrowIcon />
                </div>
                <h3>{channel.title}</h3>
                <p>{channel.description}</p>
                <span className="community-card-cta">
                  {copy.actions[link.actionKey]}
                  <ArrowIcon />
                </span>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function getFAQActionURL(action: FAQAction): string {
  switch (action) {
    case "mining":
      return SOCIAL_LINKS.telegramBot;
    case "officialTelegram":
      return SOCIAL_LINKS.telegramOfficial;
    case "communityTelegram":
      return SOCIAL_LINKS.telegramCommunity;
    case "explorer":
      return TOKEN_CONFIG.explorerUrl;
    case "buy":
      return TOKEN_CONFIG.buyUrl;
  }
}

function interpolate(text: string, values: Record<string, string>) {
  return text.replace(/\{(\w+)\}/g, (_, key: string) => values[key] ?? "");
}

function FAQSection({ copy }: { copy: Translation }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const supplyText = `${SITE_CONFIG.totalSupply} ${SITE_CONFIG.symbol}`;

  return (
    <section aria-labelledby="faq-title" className="section faq-section" id="faq">
      <div className="page-container faq-layout">
        <div className="faq-intro">
          <SectionHeading
            description={copy.faq.description}
            eyebrow={copy.faq.eyebrow}
            id="faq-title"
            title={copy.faq.title}
          />
        </div>
        <div className="faq-list">
          {copy.faq.items.map((item, index) => {
            const isOpen = openIndex === index;
            const actionURL = item.action ? getFAQActionURL(item.action) : "";
            const answer = interpolate(item.answer, { supply: supplyText });
            return (
              <article className={`faq-item ${isOpen ? "is-open" : ""}`} key={item.question}>
                <h3>
                  <button
                    aria-controls={`faq-answer-${index}`}
                    aria-expanded={isOpen}
                    className="faq-question"
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                    type="button"
                  >
                    <span>{item.question}</span>
                    <span aria-hidden="true" className="faq-toggle"><span /></span>
                  </button>
                </h3>
                <div className="faq-answer" hidden={!isOpen} id={`faq-answer-${index}`}>
                  <p>{answer}</p>
                  {item.action && actionURL && (
                    <ExternalAction
                      className="faq-action"
                      href={actionURL}
                      label={copy.faq.actionLabels[item.action]}
                      variant="text"
                    />
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Disclaimer({ title, text }: { title: string; text: string }) {
  return (
    <section aria-label={title} className="disclaimer-section">
      <div className="page-container disclaimer-inner">
        <span aria-hidden="true" className="disclaimer-symbol">!</span>
        <p>{text}</p>
      </div>
    </section>
  );
}

function Footer({ copy }: { copy: Translation }) {
  return (
    <footer className="site-footer">
      <div className="page-container">
        <div className="footer-main">
          <div className="footer-brand-column">
            <a className="brand-lockup footer-brand" href="#home">
              <CrownMark className="brand-mark" />
              <span className="brand-name">CHEIKH<span>$</span></span>
            </a>
            <span className="footer-symbol" dir="ltr">{SITE_CONFIG.symbol}</span>
            <p><bdi dir="ltr">{copy.footer.tagline}</bdi></p>
          </div>

          <div className="footer-column">
            <h2>{copy.footer.navigate}</h2>
            <nav aria-label={copy.nav.footer} className="footer-nav">
              {FOOTER_LINKS.map((link) => (
                <a href={link.href} key={link.href}>
                  {copy.nav[link.labelKey]}
                </a>
              ))}
            </nav>
          </div>

          {FOOTER_SOCIAL_LINKS.length > 0 && (
            <div className="footer-column">
              <h2>{copy.footer.social}</h2>
              <nav aria-label={copy.nav.officialLinks} className="footer-social-links">
                {FOOTER_SOCIAL_LINKS.map((link) => (
                  <a href={link.href} key={link.id} rel="noopener noreferrer" target="_blank">
                    {copy.community.socialLabels[link.labelKey]}
                    <ArrowIcon />
                  </a>
                ))}
              </nav>
            </div>
          )}
        </div>

        <div className="footer-bottom">
          {TOKEN_CONFIG.explorerUrl ? (
            <a href={TOKEN_CONFIG.explorerUrl} rel="noopener noreferrer" target="_blank">
              <bdi dir="ltr">{copy.footer.contract}</bdi>
              <ArrowIcon />
            </a>
          ) : (
            <span><bdi dir="ltr">{copy.footer.contract}</bdi></span>
          )}
            <span>© 2026 <bdi dir="ltr">{SITE_CONFIG.projectName}</bdi>. {copy.footer.copyright}</span>
        </div>
      </div>
    </footer>
  );
}

function getInitialLanguage(): Language {
  try {
    const saved = window.localStorage.getItem("cheikh-language");
    if (LANGUAGE_CONFIG.supportedLanguages.some((language) => language === saved)) {
      return saved as Language;
    }
  } catch {
    // Use the configured default when storage is unavailable.
  }
  return LANGUAGE_CONFIG.defaultLanguage;
}

export default function App() {
  const [language, setLanguage] = useState<Language>(getInitialLanguage);
  const copy = translations[language];

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";

    try {
      window.localStorage.setItem("cheikh-language", language);
    } catch {
      // Storage can be unavailable in private browsing; language still works for this session.
    }

    const existingCanonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (SITE_CONFIG.websiteUrl) {
      const canonical = existingCanonical ?? document.createElement("link");
      canonical.rel = "canonical";
      canonical.href = SITE_CONFIG.websiteUrl;
      if (!existingCanonical) document.head.appendChild(canonical);
    } else if (existingCanonical) {
      existingCanonical.remove();
    }

    const publicBase = SITE_CONFIG.websiteUrl || window.location.origin;
    const absoluteShareImage = new URL("/images/chkh-coin-hero.jpg", publicBase).toString();
    const openGraphImage = document.querySelector<HTMLMetaElement>('meta[property="og:image"]');
    const twitterImage = document.querySelector<HTMLMetaElement>('meta[name="twitter:image"]');
    if (openGraphImage) openGraphImage.content = absoluteShareImage;
    if (twitterImage) twitterImage.content = absoluteShareImage;
  }, [language]);

  return (
    <>
      <a className="skip-link" href="#main-content">{copy.skipToContent}</a>
      <Header copy={copy} language={language} onLanguageChange={setLanguage} />
      <main id="main-content">
        <HeroSection copy={copy} />
        <AboutSection copy={copy} />
        <TokenomicsSection copy={copy} />
        <TransparencySection copy={copy} />
        <HowItWorksSection copy={copy} />
        <RoadmapSection copy={copy} />
        <CommunitySection copy={copy} />
        <FAQSection copy={copy} />
        <Disclaimer text={copy.disclaimer} title={copy.disclaimerTitle} />
      </main>
      <Footer copy={copy} />
    </>
  );
}